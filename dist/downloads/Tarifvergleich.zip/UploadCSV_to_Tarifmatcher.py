"""
UploadCSV_to_Tarifmatcher.py

Ein Beispielskript, das:
 - Argumente (Upload-CSV & Download-Ordner) einliest
 - Per Selenium die Upload-Seite öffnet und CSV hochlädt
 - Eine Schleife nutzt, um den Status aus data-react-props zu poll'en
   (und StaleElementReferenceException zu vermeiden)
 - Nach Fertigmeldung die Dateien via requests herunterlädt
 - Optional per DELETE-Request das BatchFile löscht
"""
# Beispielaufruf:
# python C:\Users\beata\OneDrive\Dokumente\Organisation\OAAT\xmlTransformation\UploadCSV_to_Tarifmatcher.py --Upload_CSV "C:\Users\beata\OneDrive\Dokumente\Organisation\OAAT\xmlTransformation\PatientLeistungen.csv" --DownloadDir "C:\Users\beata\OneDrive\Dokumente\Organisation\OAAT\xmlTransformation"

import time
import os
import requests
import json
import html
import argparse

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait, Select
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.common.exceptions import (
    TimeoutException,
    StaleElementReferenceException,
    NoSuchElementException,
)
from webdriver_manager.chrome import ChromeDriverManager

#********************************************************************************************************************
# Hilfsfunktionen
#********************************************************************************************************************

def remove_file_if_exists(file_path):
    """Löscht die angegebene Datei, falls sie existiert."""
    if os.path.isfile(file_path):
        os.remove(file_path)
        print(f"Datei '{file_path}' wurde gelöscht.")
    else:
        print(f"Datei '{file_path}' nicht gefunden oder bereits gelöscht.")

def cleanup_files(download_folder):
    # Ergebnisdateien entfernen
    grouper_file = os.path.join(download_folder, "grouper_result.csv")
    transcode_file = os.path.join(download_folder, "transcode_result.csv")

    remove_file_if_exists(grouper_file)
    remove_file_if_exists(transcode_file)

def wait_until_file_ready(file_path, timeout=30):
    """
    Wartet bis zu 'timeout' Sekunden, bis die Datei 'file_path' existiert
    und größer als 0 Byte ist.
    Gibt True zurück, sobald die Datei bereit ist, sonst False.
    """
    start = time.time()
    while time.time() - start < timeout:
        if os.path.isfile(file_path) and os.path.getsize(file_path) > 0:
            return True
        time.sleep(1)
    return False

def ensure_files_ready(download_folder):
    """
    Prüft, ob grouper_result.csv und transcode_result.csv beide
    rechtzeitig existieren und > 0 Byte haben.
    """
    grouper_csv = os.path.join(download_folder, "grouper_result.csv")
    transcode_csv = os.path.join(download_folder, "transcode_result.csv")

    all_ok = True

    if not wait_until_file_ready(grouper_csv, timeout=30):
        print("❌ Fehler: grouper_result.csv ist nicht rechtzeitig verfügbar!")
        all_ok = False

    if not wait_until_file_ready(transcode_csv, timeout=30):
        print("❌ Fehler: transcode_result.csv ist nicht rechtzeitig verfügbar!")
        all_ok = False

    if all_ok:
        print("✅ Beide Ergebnisdateien sind lokal verfügbar und haben > 0 Byte.")

# ********************************************************************************************************************
# Hauptfunktion
# ********************************************************************************************************************
def main():
    DEBUG = False  # oder True für ausführliche Debug-Ausgaben
    parser = argparse.ArgumentParser(description="Upload CSV und Download Ergebnisse")
    parser.add_argument(
        "--Upload_CSV",
        default=r"C:\Temp\PatientLeistungen.csv",
        help="Pfad zur CSV-Datei für den Upload (Default: C:\\Temp\\PatientLeistungen.csv)",
    )
    parser.add_argument(
        "--DownloadDir",
        default=r"C:\Temp",
        help="Verzeichnis zum Speichern der Ergebnisse (Default: C:\\Temp)",
    )
    args = parser.parse_args()

    upload_csv = args.Upload_CSV
    download_folder = args.DownloadDir

    # Allenfalls bestehende Ergebnis CSV-Dateien löschen
    cleanup_files(download_folder)

    # Browser-Start
    options = webdriver.ChromeOptions()
    # options.add_argument("--headless")  # Headless optional
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
    wait = WebDriverWait(driver, 60)

    # Requests-Session
    session = requests.Session()

    try:
        # 1) Hauptseite öffnen
        driver.get("https://tarifmatcher.oaat-otma.ch/batch?locale=de")

        # CSRF-Token aus <meta name="csrf-token"> auslesen
        try:
            meta_csrf = wait.until(
                EC.presence_of_element_located((By.XPATH, "//meta[@name='csrf-token']"))
            )
            csrf_token = meta_csrf.get_attribute("content")
        except TimeoutException:
            csrf_token = None
        print("CSRF-Token:", csrf_token)

        # 2) Formular ausfüllen
        Select(wait.until(EC.element_to_be_clickable((By.ID, "batch_file_format")))).select_by_value("batchgrouper")

        case_checkbox = driver.find_element(By.ID, "do_case_splitting")
        if not case_checkbox.is_selected():
            case_checkbox.click()

        transcode_checkbox = driver.find_element(By.ID, "do_transcode")
        if not transcode_checkbox.is_selected():
            transcode_checkbox.click()

        file_input = driver.find_element(By.ID, "batch_file_batch_file")
        file_input_path = os.path.abspath(upload_csv)
        if not os.path.isfile(file_input_path):
            raise FileNotFoundError(f"Datei nicht gefunden: {file_input_path}")
        file_input.send_keys(file_input_path)

        # Abschicken
        driver.find_element(By.XPATH, "//button[@type='submit' and contains(text(),'Gruppieren')]").click()

        # 3) Auf "Finished" warten, per Polling
        batch_file_id = None
        max_seconds = 300
        start_time = time.time()

        while True:
            # Timeout?
            if (time.time() - start_time) > max_seconds:
                raise TimeoutException("Verarbeitung war nach 300s nicht 'Finished'.")

            try:
                # NEU finden pro Schleife, um StaleElementReference zu vermeiden
                import_div = driver.find_element(By.XPATH, "//div[@data-react-class='ImportProgressPage']")
                props_json = import_div.get_attribute("data-react-props")
                data = json.loads(html.unescape(props_json))
                status = data["batchFile"]["status"]
                print("Aktueller Status:", status)

                if "Finished" in status:
                    batch_file_id = data["batchFileId"]
                    print("✅ Verarbeitung: 'Finished successfully'")
                    break
            except (NoSuchElementException, StaleElementReferenceException):
                pass

            time.sleep(2)

        if not batch_file_id:
            raise RuntimeError("Konnte batchFileId nicht ermitteln.")

        # 4) Kurze Extra-Pause vor Download
        time.sleep(2)

        # 5) Cookies in Requests-Session übernehmen
        for cookie in driver.get_cookies():
            session.cookies.set(cookie['name'], cookie['value'])

        # Rails erwartet meist CSRF-Token + X-Requested-With
        if csrf_token:
            session.headers.update({
                "X-CSRF-Token": csrf_token,
                "X-Requested-With": "XMLHttpRequest"
            })

        # 6) Ergebnis-Download
        base_url = "https://tarifmatcher.oaat-otma.ch"
        download_grouper_url = f"{base_url}/batch_files/{batch_file_id}/download_result"
        download_transcode_url = f"{base_url}/batch_files/{batch_file_id}/download_result?get_transcoding_output=1"

        # a) Grouper-Result
        resp_g = session.get(download_grouper_url)
        print("Download Grouper:", resp_g.status_code, resp_g.headers.get("Content-Type", ""))
        if resp_g.status_code == 200 and "text/csv" in resp_g.headers.get("Content-Type", ""):
            grouper_csv = os.path.join(download_folder, "grouper_result.csv")
            with open(grouper_csv, "wb") as f:
                f.write(resp_g.content)
            print(f"✅ Gruppierungsergebnis gespeichert: {grouper_csv}")
        else:
            print(f"⚠️ Download Grouper fehlgeschlagen, Status={resp_g.status_code}")
            if DEBUG:
                print("Erste Zeilen vom Response:\n", resp_g.text[:300])

        # b) Transcode-Result
        resp_t = session.get(download_transcode_url)
        print("Download Transcode:", resp_t.status_code, resp_t.headers.get("Content-Type", ""))
        if resp_t.status_code == 200 and "text/csv" in resp_t.headers.get("Content-Type", ""):
            transcode_csv = os.path.join(download_folder, "transcode_result.csv")
            with open(transcode_csv, "wb") as f:
                f.write(resp_t.content)
            print(f"✅ Transcodierungsergebnis gespeichert: {transcode_csv}")
        else:
            print(f"⚠️ Download Transcode fehlgeschlagen, Status={resp_t.status_code}")
            if DEBUG:
                print("Erste Zeilen vom Response:\n", resp_t.text[:300])

        # -------------------------------------------------
        # 7) BatchFile mit POST "_method=delete"
        # -------------------------------------------------
        delete_url = f"{base_url}/batch_files/{batch_file_id}"

        # POST-Daten: Rails erkennt daran "delete"
        data = {
            "_method": "delete",
            "authenticity_token": csrf_token,
            # Optional z.B.: "commit": "Löschen"
        }

        resp_del = session.post(delete_url, data=data)
        print("Delete BatchFile:", resp_del.status_code)

        # Rails leitet bei Erfolg oft mit 302 um, statt 204 o.ä.
        if resp_del.status_code in (200, 204, 302):
            print("✅ BatchFile wurde gelöscht.")
        else:
            print(f"⚠️ BatchFile nicht gelöscht, Status={resp_del.status_code}")
            if DEBUG:
                print("Erste Zeilen vom Response:\n", resp_del.text[:300])

        # -------------------------------------------------
        # 8) Sicherstellen, dass Ergebnisdateien verfügbar sind
        # -------------------------------------------------
        ensure_files_ready(download_folder)

    finally:
        driver.quit()
        print("Browser geschlossen.")


if __name__ == "__main__":
    main()
