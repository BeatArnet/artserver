#!/usr/bin/env pythonw
# -*- coding: utf-8 -*-

###############################################################################
# ImportXML.py – Dokumentation / Programmaufruf
#
# Dieses Skript importiert XML-Dateien in eine MS-Access-Datenbank.
# Es verwendet Tkinter für eine GUI-Fortschrittsanzeige und kann
# folgende Argumente über die Kommandozeile entgegennehmen:
#
#   1) --XML_InputDir
#       Verzeichnis, aus dem die XML-Dateien gelesen werden.
#       Default:
#         "C:\Users\beata\OneDrive\Dokumente\Organisation\OAAT\Neuer_Arzttarif\Tarmed_Rechnungen"
#
#   2) --DB_OutputDir
#       Verzeichnis, in dem sich die Access-Datenbank mit den Daten befindet (also nicht das Programm selber).
#       Default: None (Verwendung eines Standardpfads im Skript)
#       Wichtig: Der Dateiname der Datenbank muss "Tarifvergleich_data.accdb" lauten.
#
#   3) --Anzahl_Dateien
#       Maximale Anzahl zu verarbeitender XML-Dateien.
#       Default: 10000
#
#   4) --anonymize
#       Wenn dieser Flag gesetzt ist (default=True),
#       werden schützenswerte Patientendaten (Name, Vorname, Geburtsdatum, Straße)
#       NICHT gespeichert. Stattdessen berechnet das Skript das Alter (Feld 'age').
#
#
# Beispielhafter Aufruf (Windows-Kommandozeile):
#   Mit Anonymisieren (Default)
#   python ImportXML.py ^
#     --XML_InputDir "C:\Users\beata\OneDrive\Dokumente\Organisation\OAAT\Neuer_Arzttarif\Tarmed_Rechnungen" ^
#     --DB_OutputDir "C:\Users\beata\OneDrive\Dokumente\Organisation\OAAT\xmlTransformation\Tarifvergleich" ^
#     --Anzahl_Dateien 10000 ^
#     --anonymize
# 
#    python ImportXML.py --XML_InputDir "C:\Users\beata\OneDrive\Dokumente\Organisation\OAAT\Neuer_Arzttarif\Tarmed_Rechnungen generieren\output"
#
#   Hinweis: Bei der Verwendung von --no-anonymize wird das Alter in Jahren in die Datenbank geschrieben
# 
#    
#   Ohne  Anonymisieren
#   python ImportXML.py ^
#     --XML_InputDir "C:\Users\beata\OneDrive\Dokumente\Organisation\OAAT\Neuer_Arzttarif\Tarmed_Rechnungen" ^
#     --DB_OutputDir "C:\Users\beata\OneDrive\Dokumente\Organisation\OAAT\Tarifvergleich" ^
#     --Anzahl_Dateien 10000 ^
#     --no-anonymize
#
 
###############################################################################

import os
import pyodbc
import xml.etree.ElementTree as ET
import lxml.etree as LET  # Zum Validieren des XML gegen XSD
import logging
from logging.handlers import RotatingFileHandler
from datetime import datetime
import json
import argparse
import tkinter as tk
from tkinter import ttk, messagebox
from tkinter.scrolledtext import ScrolledText
import threading
import queue
import time

###############################################################################
# Argument Parsing
###############################################################################
def parse_arguments():
    parser = argparse.ArgumentParser(description="Import XML files into Access database")
    parser.add_argument("--XML_InputDir", type=str,
                        default=r"C:\Users\beata\OneDrive\Dokumente\Organisation\OAAT\Neuer_Arzttarif\Tarmed_Rechnungen_Problem",
                        help="Verzeichnis, das die XML-Dateien enthält")
    parser.add_argument("--DB_OutputDir", type=str, default=None,
                        help="Verzeichnis, in dem sich die Access-Datenbank befindet")
    parser.add_argument("--Anzahl_Dateien", type=int, default=10000,
                        help="Maximale Anzahl der zu verarbeitenden XML-Rechnungsdateien")
    # Option zum Anonymisieren der Datensätze (keine Patienten- und Versichertennamen, kein Geburtsdatum, keine Strassenangabe)
    parser.add_argument(
        "--anonymize",
        action="store_true",
        dest="anonymize",
        default=True,
        help="Anonymisierung aktivieren (Default: True)."
    )
    # und wenn ich nicht anonymisieren will, muss ich explizit --no-anonymize setzen
    parser.add_argument(
        "--no-anonymize",
        action="store_false",
        dest="anonymize",
        help="Anonymisierung ausschalten."
)
    return parser.parse_args()

args = parse_arguments()
XML_FOLDER = args.XML_InputDir
max_files = args.Anzahl_Dateien
ANONYMIZE = args.anonymize
patient_birthdate_local = None

# Falls ein anderes DB_OutputDir angegeben wurde, DB_PATH anpassen
default_db_path = r"C:\Users\beata\OneDrive\Dokumente\Organisation\OAAT\xmlTransformation\Tarifvergleich_data.accdb"
if args.DB_OutputDir:
    DB_PATH = os.path.join(args.DB_OutputDir, os.path.basename(default_db_path))
else:
    DB_PATH = default_db_path

###############################################################################
# LOGGING-KONFIGURATION MIT ROTATING FILE HANDLER
###############################################################################
LOGFILE = 'import_errors.log'
logger = logging.getLogger(__name__)
logger.setLevel(logging.WARNING)

file_handler = RotatingFileHandler(LOGFILE, maxBytes=2_000_000, backupCount=5, encoding='utf-8')
file_handler.setLevel(logging.ERROR)
file_formatter = logging.Formatter('%(asctime)s [%(levelname)s] %(message)s')
file_handler.setFormatter(file_formatter)
logger.addHandler(file_handler)

console_handler = logging.StreamHandler()
console_handler.setLevel(logging.ERROR)
console_handler.setFormatter(file_formatter)
logger.addHandler(console_handler)

###############################################################################
# KONFIGURATION Datenbank
###############################################################################
CONN_STR = f"DRIVER={{Microsoft Access Driver (*.mdb, *.accdb)}};DBQ={DB_PATH};"

###############################################################################
# HILFSFUNKTIONEN
###############################################################################
def parse_iso_date(date_str):
    if not date_str:
        return None
    try:
        return datetime.fromisoformat(date_str)
    except ValueError:
        return None

def get_identity(cursor):
    cursor.execute("SELECT @@IDENTITY")
    row = cursor.fetchone()
    return int(row[0]) if row and row[0] is not None else None

def log_and_raise_error(note, statement, params, ex):
    error_details = {
        "note": note,
        "statement": statement,
        "params": params,
        "exception": str(ex),
        "timestamp": datetime.now().isoformat()
    }
    logger.error("FEHLER beim Ausführen von: %s", note)
    logger.error("SQL Statement: %s", statement)
    for i, p in enumerate(params):
        logger.error("Param %d: %r", i, p)
    logger.error("Exception: %s", ex)
    logger.error(json.dumps(error_details, default=str))
    raise ex

def execute_with_log(cursor, statement, params, note=""):
    try:
        cursor.execute(statement, params)
    except Exception as ex:
        log_and_raise_error(note, statement, params, ex)

def add_warning(msg):
    """
    Schreibt die Warnung ins Log und schickt sie als ("warning", msg) in die Queue,
    damit die GUI sie anzeigen kann.
    """
    logger.warning(msg)
    # progress_queue.put(("warning", msg))

def compute_age(service_date, birthdate):
    """
    Ermittelt das Alter (Ganzzahl in Jahren) zum Zeitpunkt service_date - birthdate.
    Ein Kleinkind unter 1 Jahr => age = 0.
    """
    if not service_date or not birthdate:
        return None
    # einfache Jahresdifferenz
    years = service_date.year - birthdate.year
    # Wenn das aktuelle Datum den Geburtstag noch nicht erreicht hat, -1
    if (service_date.month, service_date.day) < (birthdate.month, birthdate.day):
        years -= 1
    if years < 0:
        years = 0
    return years

def get_text_or_attr(elem, ns, name):
    """
    Versucht, den Wert zuerst als Attribut 'name' auszulesen.
    Falls nichts gefunden, wird nach <name> als Sub-Element gesucht.
    Gibt None zurück, wenn beides nicht existiert.
    Beispiel: get_text_or_attr(person_el, ns_inv, 'familyname')
    """
    if elem is None:
        return None
    val_attr = elem.get(name)
    if val_attr:
        return val_attr.strip()
    # Sub-Element (evtl. Namespaced!)
    sub = elem.find(f'{ns}{name}')
    if sub is not None and sub.text:
        return sub.text.strip()
    return None

###############################################################################
# XML VALIDIERUNG (XSD-Erkennung und -Validierung)
###############################################################################
def validate_xml(xml_path):
    """
    Validiert die XML-Datei anhand der zugehörigen XSD-Datei.
    Ermittelt die XSD-Version über das schemaLocation-Attribut.
    """
    import xml.etree.ElementTree as ET
    try:
        tree = ET.parse(xml_path)
        root = tree.getroot()
    except ET.ParseError as e:
        fname = os.path.basename(xml_path)
        logger.error("XML-Parse-Fehler in Datei %s: %s", fname, e)
        print(f"Fehler: XML-Datei {fname} ist nicht wohlgeformt: {e}")
        raise

    schemaloc = root.get('{http://www.w3.org/2001/XMLSchema-instance}schemaLocation', '')
    version = None
    if "generalInvoiceRequest_440.xsd" in schemaloc or "440" in schemaloc:
        version = "440"
    elif "generalInvoiceRequest_450.xsd" in schemaloc or "450" in schemaloc:
        version = "450"
    elif "generalInvoiceRequest_500.xsd" in schemaloc or "500" in schemaloc:
        version = "500"
    else:
        fname = os.path.basename(xml_path)
        msg = f"Unbekannte XSD-Version in Datei {fname}: {schemaloc}"
        logger.error(msg)
        print("Fehler:", msg)
        raise ValueError("Unsupported XSD version")
    
    xsd_path = os.path.join(os.path.dirname(DB_PATH), f"generalInvoiceRequest_{version}.xsd")
    try:
        schema_doc = LET.parse(xsd_path)
        schema = LET.XMLSchema(schema_doc)
        xml_doc = LET.fromstring(ET.tostring(root))
        if not schema.validate(xml_doc):
            error = schema.error_log.last_error
            msg = error.message if error is not None else "Unbekannter Validierungsfehler"
            if "tiers_payant" in msg:
                logger.warning("Validierung Warnung (tiers_payant wird ignoriert) für %s (XSD %s): %s",
                               os.path.basename(xml_path), version, msg)
                warn_str = f"[WARN] XML-Datei {os.path.basename(xml_path)}: {msg} – Importiere trotzdem."
                print(warn_str)
                add_warning(warn_str)  # in die Queue
            else:
                logger.error("Validierung fehlgeschlagen für %s (XSD %s): %s", 
                             os.path.basename(xml_path), version, msg)
                print(f"Fehler: XML-Datei {os.path.basename(xml_path)} entspricht nicht XSD {version}: {msg}")
                raise LET.DocumentInvalid(msg)
    except Exception as e:
        fname = os.path.basename(xml_path)
        logger.error("Validierung fehlgeschlagen für %s (XSD %s): %s", fname, version, e)
        print(f"Fehler: XML-Datei {fname} kann nicht validiert werden (XSD {version}): {e}")
        raise

    return root, version

###############################################################################
# IMPORT-FUNKTION: Importiert eine XML-Datei in die Datenbank
###############################################################################
def import_invoice(xml_path, cursor):
    """
    Importiert eine XML-Datei in die Access-Datenbank.
    - Validiert das XML
    - Extrahiert relevante Daten aus <payload> und <body>
    - Speichert die Daten in den entsprechenden Tabellen

    Neu: Bei ANONYMIZE=True werden schützenswerte Daten (Name, Vorname, Geburtsdatum, Strasse)
    nicht in die Datenbank gespeichert. Stattdessen wird in 'Service' eine neue Spalte 'age'
    befüllt, die aus (service.date_begin - patient_birthdate) berechnet wird.
    """
    global ANONYMIZE
    global patient_birthdate_local

    try:
        root, xsd_version = validate_xml(xml_path)
    except Exception as e:
        print(f"Import abgebrochen: {e}")
        return

    ns_inv = '{http://www.forum-datenaustausch.ch/invoice}'
    fname = os.path.basename(xml_path)

    # 1) Request-Attribute aus dem Root-Element
    language = root.get('language', '')
    modus = root.get('modus', '')
    try:
        val_status = int(root.get('validation_status', '0'))
    except:
        val_status = 0
    source_file_name = fname
    source_file_path = os.path.abspath(xml_path)
    import_date = datetime.now()
    last_modified_date = datetime.fromtimestamp(os.path.getmtime(xml_path))

    # 2) Payload (invoice, reminder, credit etc.)
    payload_el = root.find(f'{ns_inv}payload')
    if payload_el is None:
        print(f"Fehler: Kein <payload>-Element in {fname}")
        return

    p_type = payload_el.get('type', payload_el.get('request_type', 'invoice'))
    subtype = payload_el.get('request_subtype', '')
    if subtype.lower() in ('cancellation', 'storno'):
        storno = True
    else:
        storno = (payload_el.get('storno', 'false').lower() == 'true')
    copyval = (payload_el.get('copy', 'false').lower() == 'true')

    invoice_el = payload_el.find(f'{ns_inv}invoice')
    reminder_el = payload_el.find(f'{ns_inv}reminder')
    credit_el = payload_el.find(f'{ns_inv}credit')

    inv_id = None; inv_date = None; inv_ts = 0
    if invoice_el is not None:
        inv_id = invoice_el.get('request_id')
        inv_date = parse_iso_date(invoice_el.get('request_date'))
        try:
            inv_ts = int(invoice_el.get('request_timestamp', '0'))
        except:
            pass

    rem_id = None; rem_date = None; rem_ts = 0; rem_level = None; rem_text = None
    if reminder_el is not None:
        rem_id = reminder_el.get('request_id')
        rem_date = parse_iso_date(reminder_el.get('request_date'))
        try:
            rem_ts = int(reminder_el.get('request_timestamp', '0'))
        except:
            pass
        rem_level = reminder_el.get('reminder_level')
        rem_text = reminder_el.get('reminder_text')

    cred_id = None; cred_date = None; cred_ts = 0
    if credit_el is not None:
        cred_id = credit_el.get('request_id')
        cred_date = parse_iso_date(credit_el.get('request_date'))
        try:
            cred_ts = int(credit_el.get('request_timestamp', '0'))
        except:
            pass

    # 3) <processing>
    processing_el = root.find(f'{ns_inv}processing')
    print_intermediate = False
    print_copy_guarantor = False
    transport_from = None
    transport_to = None
    transport_via = None
    if processing_el is not None:
        print_intermediate = (processing_el.get('print_at_intermediate', 'false').lower() == 'true')
        # in manchen XMLs heißt es print_copy_to_guarantor, in anderen print_patient_copy
        if processing_el.get('print_copy_to_guarantor') is not None:
            print_copy_guarantor = (processing_el.get('print_copy_to_guarantor', 'false').lower() == 'true')
        else:
            print_copy_guarantor = (processing_el.get('print_patient_copy', 'false').lower() == 'true')
        transport_el = processing_el.find(f'{ns_inv}transport')
        if transport_el is not None:
            transport_from = transport_el.get('from')
            transport_to = transport_el.get('to')
            via_list = [via.get('via') for via in transport_el.findall(f'{ns_inv}via') if via.get('via')]
            if via_list:
                transport_via = ",".join(via_list)

    # 4) Insert in die Request-Tabelle
    sql_req = """
    INSERT INTO [Request] (
        language, modus, validation_status, type, storno, copy, 
        invoice_request_id, invoice_request_date, invoice_request_timestamp, 
        reminder_request_id, reminder_request_date, reminder_request_timestamp, 
        reminder_level, reminder_text, credit_request_id, 
        credit_request_date, credit_request_timestamp, 
        print_at_intermediate, print_copy_to_guarantor,
        transport_from, transport_to, transport_via,
        source_file_name, source_file_path, import_date, last_modified_date
    )
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    """
    params_req = (
        language, modus, val_status,
        p_type, storno, copyval,
        inv_id, inv_date, inv_ts,
        rem_id, rem_date, rem_ts, rem_level, rem_text,
        cred_id, cred_date, cred_ts,
        print_intermediate, print_copy_guarantor,
        transport_from, transport_to, transport_via,
        source_file_name, source_file_path, import_date, last_modified_date
    )
    execute_with_log(cursor, sql_req, params_req, note='Insert Request')
    cursor.commit()
    request_id = get_identity(cursor)
    print(f"XML {fname} importiert, RequestID={request_id}")

    # -------------------------------------------------------------------------
    # <body> verarbeiten
    # -------------------------------------------------------------------------
    body_el = payload_el.find(f'{ns_inv}body')
    if body_el is None:
        print(f"Keine <body> in {fname}, RequestID={request_id}")
        return

    # generator
    generator_el = body_el.find(f'{ns_inv}generator')
    if generator_el is not None and generator_el.text:
        sql_generator = """
        UPDATE [Request]
        SET generator = ?
        WHERE RequestID = ?
        """
        execute_with_log(cursor, sql_generator, (generator_el.text, request_id), note='Update Request.generator')
        cursor.commit()

    # Warnung für Elemente in <body>, die (noch) nicht gezielt verarbeitet werden
    handled_body_tags = {
        'prolog', 'balance', 'tiers_payant', 'tiers_garant', 
        'kvg', 'treatment', 'services', 'generator'
    }
    all_body_tags = set()
    for elem in body_el.iter():
        if '}' in elem.tag:
            tag_local = elem.tag.split('}', 1)[1]
            all_body_tags.add(tag_local)
        else:
            all_body_tags.add(elem.tag)
    for tag in sorted(all_body_tags - handled_body_tags):
        msg = f"Element <{tag}> aus <body> in {fname} nicht gezielt verarbeitet"
        print(f"[WARN] {msg}")
        add_warning(f"[WARN] {msg}")

    # balance
    balance_el = body_el.find(f'{ns_inv}balance')
    if balance_el is not None:
        currency = balance_el.get('currency')
        amount = float(balance_el.get('amount', '0'))
        amount_reminder = float(balance_el.get('amount_reminder', '0'))
        amount_due = float(balance_el.get('amount_due', '0'))
        amount_obligations = float(balance_el.get('amount_obligations', '0'))
        sql_bal = """
        INSERT INTO [Balance] (
            RequestID, [currency], amount, amount_reminder, 
            amount_due, amount_obligations
        )
        VALUES (?,?,?,?,?,?)
        """
        params_bal = (request_id, currency, amount, amount_reminder, amount_due, amount_obligations)
        execute_with_log(cursor, sql_bal, params_bal, note='Insert Balance')
        cursor.commit()

    # -------------------------------------------------------------------------
    # Verarbeitung von Parteien (<tiers_payant> oder <tiers_garant>)
    # -------------------------------------------------------------------------
    tiers_el = body_el.find(f'{ns_inv}tiers_payant')
    if tiers_el is None:
        # manche XMLs haben <tiers_garant> statt <tiers_payant>
        tiers_el = body_el.find(f'{ns_inv}tiers_garant')

    def create_contact(elem, skip_sensitive=False):
        """
        Legt einen Datensatz in der Contact-Tabelle an (inkl. PostalAddress und ContactChannel).
        Gibt die ContactID zurück oder None, wenn 'elem' leer ist.
        Bei skip_sensitive=True werden Name, Vorname und Strasse NICHT gespeichert.
        """
        if elem is None:
            return None
        
        ns = '{http://www.forum-datenaustausch.ch/invoice}'

        def create_postal_address(postal_elem, skip_street=False):
            if postal_elem is None:
                return None

            pobox  = postal_elem.get('pobox')  or postal_elem.findtext(f'{ns}pobox',  '')
            street = postal_elem.get('street') or postal_elem.findtext(f'{ns}street', '')
            city   = postal_elem.get('city')   or postal_elem.findtext(f'{ns}city',   '')

            zip_attr      = postal_elem.get('zip')
            statecode     = postal_elem.get('statecode')
            countrycode   = postal_elem.get('countrycode')

            if not zip_attr:
                zip_el = postal_elem.find(f'{ns}zip')
                if zip_el is not None:
                    zip_attr    = zip_el.text or ''
                    statecode   = statecode   or zip_el.get('statecode', '')
                    countrycode = countrycode or zip_el.get('countrycode', '')

            if skip_street:
                street = ''  # Strasse leeren

            pobox  = pobox.strip()  if pobox  else None
            street = street.strip() if street else None
            city   = city.strip()   if city   else None
            zip_attr   = zip_attr.strip()   if zip_attr   else None
            statecode   = statecode  if statecode  else None
            countrycode = countrycode if countrycode else None

            sql_p = """
                INSERT INTO [PostalAddress]
                    (pobox, street, zip, city, statecode, countrycode)
                VALUES (?,?,?,?,?,?)
            """
            params_p = (pobox, street, zip_attr, city, statecode, countrycode)
            execute_with_log(cursor, sql_p, params_p, note='Insert PostalAddress')
            cursor.commit()

            return get_identity(cursor)

        def add_channel(cid, channel_type, value):
            if not value:
                return
            sql_chan = """
            INSERT INTO [ContactChannel] (ContactID, ChannelType, Value)
            VALUES (?,?,?)
            """
            params_chan = (cid, channel_type, value.strip())
            execute_with_log(cursor, sql_chan, params_chan, note=f'Insert Channel {channel_type}')
            cursor.commit()

        company_el = elem.find(f'{ns}company')
        person_el  = elem.find(f'{ns}person')

        ctype   = None
        fam     = None
        giv     = None
        sal     = None
        title   = None
        compn   = None
        dept    = None
        suba    = None
        postal_id = None

        tel_el = None
        onl_el = None

        if company_el is not None:
            ctype = "company"
            compn = company_el.get('companyname') or company_el.findtext(f'{ns}companyname', '')
            dept  = company_el.get('department')  or company_el.findtext(f'{ns}department', '')
            suba  = company_el.get('subaddressing') or company_el.findtext(f'{ns}subaddressing', '')

            postal_el = company_el.find(f'{ns}postal')
            if postal_el is None:
                postal_el = elem.find(f'{ns}postal')

            # Auch bei Firmen anonymisieren wir die Strasse, wenn anonymize=True
            postal_id = create_postal_address(postal_el, skip_street=True if ANONYMIZE else False)
            # Bei Firmen anonymisieren wir NICHT 
            #postal_id = create_postal_address(postal_el, skip_street=False if not skip_sensitive else True)

            tel_el = company_el.find(f'{ns}tel')
            onl_el = company_el.find(f'{ns}url')

        elif person_el is not None:
            ctype = "person"
            fam   = person_el.get('familyname')  or person_el.findtext(f'{ns}familyname',  '')
            giv   = person_el.get('givenname')   or person_el.findtext(f'{ns}givenname',   '')
            sal   = person_el.get('salutation')
            title = person_el.get('title')
            suba  = person_el.findtext(f'{ns}subaddressing', '')

            postal_el = person_el.find(f'{ns}postal')
            if postal_el is None:
                postal_el = elem.find(f'{ns}postal')

            postal_id = create_postal_address(postal_el, skip_street=skip_sensitive)

            tel_el = person_el.find(f'.//{ns}tel')
            if tel_el is None:
                tel_el = elem.find(f'{ns}telecom')

            onl_el = person_el.find(f'.//{ns}url')
            if onl_el is None:
                onl_el = elem.find(f'{ns}url')

            if skip_sensitive:
                fam = ""  # Nachname leeren
                giv = ""  # Vorname leeren

        else:
            # Weder <company> noch <person>
            return None

        sql_c = """
        INSERT INTO [Contact] (
            type, familyname, givenname, salutation, title,
            companyname, department, subaddressing, PostalAddressID
        )
        VALUES (?,?,?,?,?,?,?,?,?)
        """
        params_c = (ctype, fam, giv, sal, title, compn, dept, suba, postal_id)
        execute_with_log(cursor, sql_c, params_c, note='Insert Contact')
        cursor.commit()
        contact_id = get_identity(cursor)

        if tel_el is not None:
            for ph in tel_el.findall('phone'):
                if ph.text:
                    add_channel(contact_id, 'PHONE', ph.text)
            for fx in tel_el.findall('fax'):
                if fx.text:
                    add_channel(contact_id, 'FAX', fx.text)

        if onl_el is not None:
            for em in onl_el.findall('email'):
                if em.text:
                    add_channel(contact_id, 'EMAIL', em.text)
            for u in onl_el.findall('url'):
                if u.text:
                    add_channel(contact_id, 'URL', u.text)

        return contact_id

    def insert_party(elem, party_type: str):
        global ANONYMIZE
        global patient_birthdate_local

        if elem is None:
            return
        
        skip_sens = False
        # Falls Patient/Insured und anonymize=True => skip_sens=True
        if (ANONYMIZE and party_type in ('PATIENT', 'INSURED', 'GUARANTOR', 'REFERRER', 'PROVIDER','BILLER', 'INSURANCE')):
            skip_sens = True

        contact_id = create_contact(elem, skip_sensitive=skip_sens)

        # Geburtsdatum lokal speichern, damit wir später bei "Services" das Alter berechnen können
        bd = parse_iso_date(elem.get('birthdate'))
        if party_type in ('PATIENT','INSURED') and bd is not None:
            # Nur dann lokal speichern
            patient_birthdate_local = bd
            # Falls anonymisiert, bd NICHT ins DB-Feld übernehmen
            if ANONYMIZE:
                bd = None

        ean = elem.get('ean_party')
        zsr = elem.get('zsr')
        specialty_el = elem.find(f'{ns_inv}specialty')
        if specialty_el is not None:
            specialty = specialty_el.get('specialization')
        else:
            specialty = None
        uid_number = elem.get('uid_number')
        reg_number = elem.get('reg_number')

        gender = elem.get('gender')
        ssn = elem.get('ssn')
        card_id = None
        expiry_date = None
        validation_date = None
        validation_id = None
        validation_server = None

        card_el = elem.find('card')
        if card_el is not None:
            card_id = card_el.get('card_id')
            expiry_date = parse_iso_date(card_el.get('expiry_date'))
            validation_date = parse_iso_date(card_el.get('validation_date'))
            validation_id = card_el.get('validation_id')
            validation_server = card_el.get('validation_server')

        sql_p = """
        INSERT INTO [Party] (
            RequestID, ContactID, PartyType,
            ean_party, zsr, specialty, uid_number, reg_number,
            birthdate, gender, ssn, card_id, expiry_date, validation_date, validation_id, validation_server
        )
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """
        params_p = (
            request_id, contact_id, party_type,
            ean, zsr, specialty, uid_number, reg_number,
            bd, gender, ssn, card_id, expiry_date, validation_date, validation_id, validation_server
        )
        execute_with_log(cursor, sql_p, params_p, note=f'Insert Party {party_type}')
        cursor.commit()

    if tiers_el is not None:
        for party_tag in ['biller', 'provider', 'insurance', 'patient', 'insured', 'guarantor', 'referrer']:
            party_el = tiers_el.find(f'{ns_inv}{party_tag}')
            if party_el is not None:
                insert_party(party_el, party_tag.upper())

    # -------------------------------------------------------------------------
    # <kvg>
    # -------------------------------------------------------------------------
    kvg_el = body_el.find(f'{ns_inv}kvg')
    if kvg_el is not None:
        insured_id = kvg_el.get('insured_id')
        case_date_str = kvg_el.get('case_date')
        if case_date_str:
            case_date = parse_iso_date(case_date_str)
            sql_kvg = """
            UPDATE [Request]
            SET insured_id = ?, case_date = ?
            WHERE RequestID = ?
            """
            params_kvg = (insured_id, case_date, request_id)
        else:
            sql_kvg = """
            UPDATE [Request]
            SET insured_id = ?
            WHERE RequestID = ?
            """
            params_kvg = (insured_id, request_id)
        execute_with_log(cursor, sql_kvg, params_kvg, note='Update Request with insured_id / case_date')
        cursor.commit()

    # -------------------------------------------------------------------------
    # <treatment>
    # -------------------------------------------------------------------------
    treatment_el = body_el.find(f'.//{ns_inv}treatment')
    if treatment_el is not None:
        date_begin = parse_iso_date(treatment_el.get('date_begin'))
        date_end = parse_iso_date(treatment_el.get('date_end'))
        canton = treatment_el.get('canton')
        reason = treatment_el.get('reason')
        apid = treatment_el.get('apid')
        acid = treatment_el.get('acid')
        gestation_week13 = None
        treatment_type = "unknown"
        xtra_hospital_el = treatment_el.find(f'{ns_inv}xtra_hospital')
        if xtra_hospital_el is not None:
            amb_el = xtra_hospital_el.find(f'{ns_inv}ambulatory')
            if amb_el is not None:
                treatment_type = "ambulatory"

        sql_treat = """
        INSERT INTO [Treatment] (
            RequestID,
            date_begin,
            date_end,
            gestation_week13,
            canton,
            treatment_type,
            reason,
            apid,
            acid
        )
        VALUES (?,?,?,?,?,?,?,?,?)
        """
        params_treat = (
            request_id,
            date_begin,
            date_end,
            gestation_week13,
            canton,
            treatment_type,
            reason,
            apid,
            acid
        )
        execute_with_log(cursor, sql_treat, params_treat, note='Insert Treatment')
        cursor.commit()

        diag_elems = treatment_el.findall(f'{ns_inv}diagnosis')
        for diag in diag_elems:
            diag_code = diag.get('code')
            sql_diag = """
            INSERT INTO [Diagnosis] (RequestID, code)
            VALUES (?,?)
            """
            params_diag = (request_id, diag_code)
            execute_with_log(cursor, sql_diag, params_diag, note='Insert Diagnosis')
            cursor.commit()

    # -------------------------------------------------------------------------
    # <services>
    # -------------------------------------------------------------------------
    services_el = body_el.find(f'{ns_inv}services')
    if services_el is not None:
        for s in services_el:
            tagname = s.tag.split('}', 1)[1]
            if tagname.startswith('service') or tagname.startswith('record_'):
                record_id = s.get('record_id')
                tariff_type = s.get('tariff_type')
                code = s.get('code')
                ref_code = s.get('ref_code')
                name = s.get('name')
                session = s.get('session')
                quantity = float(s.get('quantity', '0'))
                date_begin = parse_iso_date(s.get('date_begin'))
                date_end = parse_iso_date(s.get('date_end'))
                provider_id = s.get('provider_id')
                responsible_id = s.get('responsible_id')
                billing_role = s.get('billing_role')
                medical_role = s.get('medical_role')
                body_location = s.get('body_location')
                treatment = s.get('treatment')
                unit_mt = float(s.get('unit_mt', '0'))
                unit_factor_mt = float(s.get('unit_factor_mt', '0'))
                scale_factor_mt = float(s.get('scale_factor_mt', '1'))
                external_factor_mt = float(s.get('external_factor_mt', '1'))
                amount_mt = float(s.get('amount_mt', '0'))
                unit_tt = float(s.get('unit_tt', '0'))
                unit_factor_tt = float(s.get('unit_factor_tt', '0'))
                scale_factor_tt = float(s.get('scale_factor_tt', '1'))
                external_factor_tt = float(s.get('external_factor_tt', '1'))
                amount_tt = float(s.get('amount_tt', '0'))
                amount = float(s.get('amount', '0'))
                vat_rate = float(s.get('vat_rate', '0'))
                unit = float(s.get('unit', '0'))
                external_factor = float(s.get('external_factor', '0'))
                unit_factor = float(s.get('unit_factor', '0'))

                if not provider_id:
                    provider_el = s.find(f'{ns_inv}provider')
                    if provider_el is not None:
                        provider_id = provider_el.get('ean_party')
                if not responsible_id:
                    responsibility_el = s.find(f'{ns_inv}responsibility')
                    if responsibility_el is not None:
                        responsible_id = responsibility_el.get('ean_party')

                # Alter berechnen, falls patient_birthdate_local existiert
                age_val = None
                if patient_birthdate_local:
                    age_val = compute_age(date_begin, patient_birthdate_local)

                # Neuen Datensatz in [Service] inkl. age
                # HINWEIS: In der Access-DB muss das Feld 'age' zuvor erstellt werden.
                sql_serv = """
                INSERT INTO [Service] (
                    RequestID, record_id, tariff_type, code, ref_code, name, session, quantity,
                    date_begin, date_end, provider_id, responsible_id, billing_role, medical_role,
                    body_location, treatment, unit_mt, unit_factor_mt, scale_factor_mt, external_factor_mt, amount_mt,
                    unit_tt, unit_factor_tt, scale_factor_tt, external_factor_tt, amount_tt, amount, vat_rate, 
                    unit, external_factor, unit_factor, age
                )
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """
                params_serv = (
                    request_id, record_id, tariff_type, code, ref_code, name, session, quantity,
                    date_begin, date_end, provider_id, responsible_id, billing_role, medical_role,
                    body_location, treatment,
                    unit_mt, unit_factor_mt, scale_factor_mt, external_factor_mt, amount_mt,
                    unit_tt, unit_factor_tt, scale_factor_tt, external_factor_tt, amount_tt,
                    amount, vat_rate, unit, external_factor, unit_factor, age_val
                )
                execute_with_log(cursor, sql_serv, params_serv, note=f'Insert Service ({tagname})')
                cursor.commit()

                if tagname == 'record_drug':
                    service_id = get_identity(cursor)
                    xtra_drug_el = s.find(f'{ns_inv}xtra_drug')
                    if xtra_drug_el is not None:
                        indicated = (xtra_drug_el.get('indicated', 'false').lower() == 'true')
                        iocm_category = xtra_drug_el.get('iocm_category')
                        delivery = xtra_drug_el.get('delivery')
                        limitation = (xtra_drug_el.get('limitation', 'false').lower() == 'true')
                        regulation_attributes = 0

                        sql_xtra_drug = """
                        INSERT INTO [XtraDrug] (
                            ServiceID, indicated, iocm_category, delivery, regulation_attributes, limitation
                        )
                        VALUES (?,?,?,?,?,?)
                        """
                        params_xtra_drug = (service_id, indicated, iocm_category, delivery, regulation_attributes, limitation)
                        execute_with_log(cursor, sql_xtra_drug, params_xtra_drug, note='Insert XtraDrug')
                        cursor.commit()
        # Jetzt sind alle Einträge in der Tabelle Service geschrieben und das zwischengespeicherte Alter kann
        # zuückgesetzt werden
        patient_birthdate_local = None
    # -------------------------------------------------------------------------
    # <caseDetail>
    # -------------------------------------------------------------------------
    case_detail_el = body_el.find(f'.//{ns_inv}caseDetail')
    if case_detail_el is not None:
        case_number = case_detail_el.get('case_number')
        case_date = parse_iso_date(case_detail_el.get('case_date'))
        sql_case = """
        INSERT INTO [CaseDetail] (RequestID, case_number, case_date)
        VALUES (?,?,?)
        """
        params_case = (request_id, case_number, case_date)
        execute_with_log(cursor, sql_case, params_case, note='Insert CaseDetail')
        cursor.commit()

    # -------------------------------------------------------------------------
    # <diagnosis> (allgemein)
    # -------------------------------------------------------------------------
    diagnosis_elements = body_el.findall(f'.//{ns_inv}diagnosis')
    for diag in diagnosis_elements:
        diag_code = diag.get('code')
        diag_description = diag.get('description')
        sql_diag = """
        INSERT INTO [Diagnosis] (RequestID, code, description)
        VALUES (?,?,?)
        """
        params_diag = (request_id, diag_code, diag_description)
        execute_with_log(cursor, sql_diag, params_diag, note='Insert Diagnosis (body)')
        cursor.commit()

    # -------------------------------------------------------------------------
    # <document>
    # -------------------------------------------------------------------------
    document_elements = body_el.findall(f'.//{ns_inv}document')
    for doc in document_elements:
        doc_type = doc.get('type')
        doc_title = doc.get('title')
        doc_content = doc.text  
        sql_doc = """
        INSERT INTO [Document] (RequestID, type, title, content)
        VALUES (?,?,?,?)
        """
        params_doc = (request_id, doc_type, doc_title, doc_content)
        execute_with_log(cursor, sql_doc, params_doc, note='Insert Document')
        cursor.commit()

    # -------------------------------------------------------------------------
    # <esrParty>
    # -------------------------------------------------------------------------
    esr_party_el = body_el.find(f'.//{ns_inv}esrParty')
    if esr_party_el is not None:
        esr_account = esr_party_el.get('account')
        esr_bank = esr_party_el.get('bank')
        sql_esr = """
        INSERT INTO [ESRParty] (RequestID, account, bank)
        VALUES (?,?,?)
        """
        params_esr = (request_id, esr_account, esr_bank)
        execute_with_log(cursor, sql_esr, params_esr, note='Insert ESRParty')
        cursor.commit()

    # -------------------------------------------------------------------------
    # <payment>
    # -------------------------------------------------------------------------
    payment_elements = body_el.findall(f'.//{ns_inv}payment')
    for pay in payment_elements:
        amount = float(pay.get('amount', '0'))
        pay_date = parse_iso_date(pay.get('date'))
        method = pay.get('method')
        sql_pay = """
        INSERT INTO [Payment] (RequestID, amount, pay_date, method)
        VALUES (?,?,?,?)
        """
        params_pay = (request_id, amount, pay_date, method)
        execute_with_log(cursor, sql_pay, params_pay, note='Insert Payment')
        cursor.commit()

    # -------------------------------------------------------------------------
    # <paymentReason>
    # -------------------------------------------------------------------------
    payment_reason_elements = body_el.findall(f'.//{ns_inv}paymentReason')
    for pr in payment_reason_elements:
        reason = pr.get('reason')
        sql_pr = """
        INSERT INTO [PaymentReason] (RequestID, reason)
        VALUES (?,?)
        """
        params_pr = (request_id, reason)
        execute_with_log(cursor, sql_pr, params_pr, note='Insert PaymentReason')
        cursor.commit()

    # -------------------------------------------------------------------------
    # <validation>
    # -------------------------------------------------------------------------
    validation_el = body_el.find(f'.//{ns_inv}validation')
    if validation_el is not None:
        val_status_text = validation_el.get('status')
        val_date = parse_iso_date(validation_el.get('date'))
        sql_valid = """
        INSERT INTO [Validation] (RequestID, status, date)
        VALUES (?,?,?)
        """
        params_valid = (request_id, val_status_text, val_date)
        execute_with_log(cursor, sql_valid, params_valid, note='Insert Validation')
        cursor.commit()

    # -------------------------------------------------------------------------
    # <xtraAmbulatory>
    # -------------------------------------------------------------------------
    xtra_amb_el = body_el.find(f'.//{ns_inv}xtraAmbulatory')
    if xtra_amb_el is not None:
        detail = xtra_amb_el.get('detail')
        sql_xtra_amb = """
        INSERT INTO [XtraAmbulatory] (RequestID, detail)
        VALUES (?,?)
        """
        params_xtra_amb = (request_id, detail)
        execute_with_log(cursor, sql_xtra_amb, params_xtra_amb, note='Insert XtraAmbulatory')
        cursor.commit()

    # -------------------------------------------------------------------------
    # <xtraDRG>
    # -------------------------------------------------------------------------
    record_drug_elements = body_el.findall(f'.//{ns_inv}record_drug')
    for rd in record_drug_elements:
        sql_max_service_id = "SELECT MAX(ServiceID) FROM Service"
        cursor.execute(sql_max_service_id)
        row = cursor.fetchone()
        if row and row[0]:
            service_id = row[0]
        else:
            logger.error("Kein Service-Datensatz in der Tabelle Service gefunden.")
            continue

        xtra_drug_el = None
        for elem in rd.iter():
            if elem.tag.split('}')[-1] == "xtra_drug":
                xtra_drug_el = elem
                break

        if xtra_drug_el is not None:
            indicated = xtra_drug_el.get('indicated', 'false').lower() == 'true'
            iocm_category = xtra_drug_el.get('iocm_category')
            delivery = xtra_drug_el.get('delivery')
            limitation = xtra_drug_el.get('limitation', 'false').lower() == 'true'
            regulation_attributes = 0

            sql_xtra_drug = """
            INSERT INTO [XtraDrug] (ServiceID, indicated, iocm_category, delivery, regulation_attributes, limitation)
            VALUES (?,?,?,?,?,?)
            """
            params_xtra_drug = (service_id, indicated, iocm_category, delivery, regulation_attributes, limitation)
            execute_with_log(cursor, sql_xtra_drug, params_xtra_drug, note='Insert XtraDrug')
            cursor.commit()

        xtra_stat_el = body_el.find(f'.//{ns_inv}xtraStationary')
        if xtra_stat_el is not None:
            station_code = xtra_stat_el.get('station_code')
            sql_xtra_stat = """
            INSERT INTO [XtraStationary] (RequestID, station_code)
            VALUES (?,?)
            """
            params_xtra_stat = (request_id, station_code)
            execute_with_log(cursor, sql_xtra_stat, params_xtra_stat, note='Insert XtraStationary')
            cursor.commit()

    cursor.commit()

###############################################################################
# QUEUE UND THREAD-STEUERUNG
###############################################################################
progress_queue = queue.Queue()
worker_thread = None

pause_event = threading.Event()  # wenn gesetzt: Import pausieren
stop_flag = False

files_done_global = 0   # Anzahl der bereits verarbeiteten Dateien
total_files_global = 0  # Gesamtanzahl der Dateien

# GUI-Elemente
root = None
gui_label_files = None
gui_progress_bar = None
gui_progress_label = None
gui_warning_text = None
btn_pause_continue = None
btn_stop = None

###############################################################################
# WORKER-FUNKTION
###############################################################################
def worker_import_files(all_xml, effective_count):
    global stop_flag
    try:
        with pyodbc.connect(CONN_STR) as conn:
            cursor = conn.cursor()

            total_files = len(all_xml)
            progress_queue.put(("total", total_files))

            for idx, file in enumerate(all_xml[:effective_count], start=1):
                progress_queue.put(("progress", (idx, total_files)))
                if stop_flag:
                    progress_queue.put(("done", None))
                    return

                while pause_event.is_set():
                    time.sleep(0.2)
                    if stop_flag:
                        progress_queue.put(("done", None))
                        return

                xml_path = os.path.join(XML_FOLDER, file)
                try:
                    import_invoice(xml_path, cursor)
                    conn.commit()
                except Exception as e:
                    logger.error("Importfehler in Datei %s: %s", file, e)
                    conn.rollback()
                    progress_queue.put(("error", f"Importfehler in Datei {file}: {e}"))

                progress_queue.put(("progress", (idx, total_files)))

            progress_queue.put(("done", None))
    except Exception as e:
        logger.critical("DB-Verbindungsfehler: %s", e)
        progress_queue.put(("error", str(e)))

###############################################################################
# POLLING-FUNKTION
###############################################################################
def poll_queue():
    global total_files_global, files_done_global

    try:
        while True:
            try:
                msg_type, payload = progress_queue.get_nowait()
            except queue.Empty:
                break

            if msg_type == "total":
                update_files_label(0, payload)
                update_progress_bar(0.0)
            elif msg_type == "progress":
                idx, total = payload
                update_files_label(idx, total)
                percent = (idx / total) * 100 if total else 0
                update_progress_bar(percent)
            elif msg_type == "warning":
                show_warning_in_gui(payload)
            elif msg_type == "error":
                show_warning_in_gui(f"[ERROR] {payload}")
                finalize_gui()
            elif msg_type == "done":
                finalize_gui()
                root.destroy()
                return  # Wichtig: Keine weiteren after-Aufrufe!

            progress_queue.task_done()

    except Exception as e:
        print(f"Fehler in poll_queue: {str(e)}")
        if gui_warning_text:
            gui_warning_text.config(state=tk.NORMAL)
            gui_warning_text.insert(tk.END, f"[ERROR] GUI-Fehler: {str(e)}\n")
            gui_warning_text.see(tk.END)
            gui_warning_text.config(state=tk.DISABLED)

    if root is not None:
        try:
            if root.winfo_exists():
                root.after(100, poll_queue)
        except tk.TclError:
            pass

def update_files_label(current, total):
    if gui_label_files:
        root.after(0, lambda: gui_label_files.config(text=f"{current} von {total} Dateien eingelesen"))

def update_progress_bar(percent):
    if gui_progress_bar and gui_progress_label:
        root.after(0, lambda: gui_progress_bar.config(value=percent))
        root.after(0, lambda: gui_progress_label.config(text=f"{percent:.1f}%"))

def show_warning_in_gui(message: str):
    if gui_warning_text:
        gui_warning_text.config(state=tk.NORMAL)
        gui_warning_text.insert(tk.END, message + "\n")
        gui_warning_text.see(tk.END)
        gui_warning_text.config(state=tk.DISABLED)

def finalize_gui():
    if btn_pause_continue:
        btn_pause_continue.config(state=tk.DISABLED)
    if btn_stop:
        btn_stop.config(state=tk.DISABLED)

###############################################################################
# BUTTON-CALLBACKS
###############################################################################
def on_pause_continue():
    if not pause_event.is_set():
        pause_event.set()
        btn_pause_continue.config(text="Weiterfahren")
    else:
        pause_event.clear()
        btn_pause_continue.config(text="Pause")

def on_stop():
    global stop_flag
    answer = messagebox.askyesno("Beenden?", "Wollen Sie wirklich den Import beenden?")
    if answer:
        stop_flag = True
        root.destroy()
    else:
        if btn_pause_continue:
            btn_pause_continue.focus_set()

###############################################################################
# HAUPTPROGRAMM
###############################################################################
def main():
    global root
    root = tk.Tk()

    global gui_label_files
    global gui_progress_bar
    global gui_progress_label
    global gui_warning_text
    global btn_pause_continue
    global btn_stop

    gui_label_files = tk.Label(root, text="0 von 0 Dateien eingelesen", font=("Arial", 11))
    gui_label_files.pack(pady=(10, 0))

    progress_frame = tk.Frame(root)
    progress_frame.pack(pady=10)

    gui_progress_bar = ttk.Progressbar(progress_frame, orient="horizontal",
                                       length=300, mode="determinate", maximum=100)
    gui_progress_bar.pack(side=tk.LEFT, padx=10)

    gui_progress_label = tk.Label(progress_frame, text="0%")
    gui_progress_label.pack(side=tk.LEFT)

    gui_warning_text = ScrolledText(root, width=90, height=15, state=tk.DISABLED)
    gui_warning_text.pack(pady=10)

    button_frame = tk.Frame(root)
    button_frame.pack(pady=5)

    btn_pause_continue = tk.Button(button_frame, text="Pause", command=on_pause_continue)
    btn_pause_continue.pack(side=tk.LEFT, padx=5)

    btn_stop = tk.Button(button_frame, text="Beenden", command=on_stop)
    btn_stop.pack(side=tk.LEFT, padx=5)

    all_xml = [f for f in os.listdir(XML_FOLDER) if f.lower().endswith('.xml')]
    real_count = len(all_xml)
    effective_count = min(real_count, max_files)

    poll_queue()
    progress_queue.put(("total", effective_count))

    global worker_thread
    worker_thread = threading.Thread(
        target=worker_import_files,
        args=(all_xml, effective_count),
        daemon=True
    )
    worker_thread.start()

    root.after(100, poll_queue)
    root.mainloop()

if __name__ == '__main__':
    main()
